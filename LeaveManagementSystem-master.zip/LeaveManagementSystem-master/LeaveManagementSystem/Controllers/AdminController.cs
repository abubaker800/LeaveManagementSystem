﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LeaveManagementSystem.Data;
using LeaveManagementSystem.Models;
using LeaveManagementSystem.Models.ViewModels;

namespace LeaveManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public AdminController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // Dashboard
        public IActionResult Index()
        {
            ViewBag.TotalEmployees = _context.Employees.Count();
            ViewBag.ActiveEmployees = _context.Employees.Count(e => e.IsActive);
            ViewBag.PendingLeaves = _context.Leaves.Count(l => l.Status == "Pending");
            ViewBag.TotalLeaves = _context.Leaves.Count();

            return View();
        }

        // Employee Management - List all employees
        public async Task<IActionResult> Employees()
        {
            var employees = await _context.Employees.ToListAsync();
            return View(employees);
        }

        // GET: Create Employee
        [HttpGet]
        public IActionResult CreateEmployee()
        {
            return View(new CreateEmployeeViewModel());
        }

        // POST: Create Employee
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEmployee(CreateEmployeeViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Check for duplicate CNIC
                    if (_context.Employees.Any(e => e.CNIC == model.CNIC))
                    {
                        ModelState.AddModelError("CNIC", "CNIC already exists");
                        return View(model);
                    }

                    // Check for duplicate Email
                    if (_context.Employees.Any(e => e.Email == model.Email))
                    {
                        ModelState.AddModelError("Email", "Email already exists");
                        return View(model);
                    }

                    // Create Identity user
                    var user = new IdentityUser
                    {
                        UserName = model.Email,
                        Email = model.Email,
                        EmailConfirmed = true
                    };

                    var result = await _userManager.CreateAsync(user, model.Password);

                    if (result.Succeeded)
                    {
                        // Assign Employee role
                        var roleResult = await _userManager.AddToRoleAsync(user, "Employee");

                        if (!roleResult.Succeeded)
                        {
                            // Rollback user creation if role assignment fails
                            await _userManager.DeleteAsync(user);
                            ModelState.AddModelError("", "Failed to assign employee role");
                            return View(model);
                        }

                        // Create Employee record
                        var employee = new EmployeeModel
                        {
                            Name = model.Name,
                            CNIC = model.CNIC,
                            Email = model.Email,
                            Department = model.Department,
                            Designation = model.Designation,
                            IsActive = model.IsActive,
                            IdentityUserId = user.Id
                        };

                        _context.Employees.Add(employee);
                        await _context.SaveChangesAsync();

                        TempData["Success"] = $"Employee '{model.Name}' created successfully! Login Email: {model.Email}";
                        return RedirectToAction(nameof(Employees));
                    }
                    else
                    {
                        // If user creation failed, add errors
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error creating employee: {ex.Message}");
                }
            }

            // Password fields will be preserved because they're part of the model
            return View(model);
        }

        // GET: Edit Employee
        [HttpGet]
        public async Task<IActionResult> EditEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Edit Employee
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEmployee(EmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var existingEmployee = await _context.Employees.FindAsync(model.EmployeeId);
                    if (existingEmployee == null)
                    {
                        return NotFound();
                    }

                    // Update only allowed fields
                    existingEmployee.Name = model.Name;
                    existingEmployee.Department = model.Department;
                    existingEmployee.Designation = model.Designation;
                    existingEmployee.IsActive = model.IsActive;
                    // CNIC, Email, and IdentityUserId remain unchanged

                    _context.Update(existingEmployee);
                    await _context.SaveChangesAsync();

                    TempData["Success"] = "Employee updated successfully";
                    return RedirectToAction(nameof(Employees));
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Please try again.");
                }
            }

            return View(model);
        }

        // POST: Toggle Employee Status (Activate/Deactivate)
        [HttpPost]
        public async Task<IActionResult> ToggleEmployeeStatus(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            employee.IsActive = !employee.IsActive;
            await _context.SaveChangesAsync();

            TempData["Success"] = $"Employee {(employee.IsActive ? "activated" : "deactivated")} successfully";
            return RedirectToAction(nameof(Employees));
        }

        // Leave Management - View all leave requests
        public async Task<IActionResult> LeaveRequests()
        {
            var leaves = await _context.Leaves
                .Include(l => l.Employee)
                .OrderByDescending(l => l.CreatedDate)
                .ToListAsync();

            return View(leaves);
        }

        // POST: Approve Leave
        [HttpPost]
        public async Task<IActionResult> ApproveLeave(int id)
        {
            var leave = await _context.Leaves.FindAsync(id);
            if (leave == null)
            {
                return NotFound();
            }

            leave.Status = "Approved";
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave approved successfully";
            return RedirectToAction(nameof(LeaveRequests));
        }

        // POST: Reject Leave
        [HttpPost]
        public async Task<IActionResult> RejectLeave(int id)
        {
            var leave = await _context.Leaves.FindAsync(id);
            if (leave == null)
            {
                return NotFound();
            }

            leave.Status = "Rejected";
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave rejected successfully";
            return RedirectToAction(nameof(LeaveRequests));
        }

        // GET: Edit Leave
        [HttpGet]
        public async Task<IActionResult> EditLeave(int id)
        {
            var leave = await _context.Leaves
                .Include(l => l.Employee)
                .FirstOrDefaultAsync(l => l.LeaveId == id);

            if (leave == null)
            {
                return NotFound();
            }

            return View(leave);
        }

        // POST: Edit Leave
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditLeave(LeaveModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var existingLeave = await _context.Leaves.FindAsync(model.LeaveId);
                    if (existingLeave == null)
                    {
                        return NotFound();
                    }

                    // Validate dates
                    if (model.EndDate < model.StartDate)
                    {
                        ModelState.AddModelError("EndDate", "End date must be after start date");
                        return View(model);
                    }

                    // Update leave details
                    existingLeave.LeaveType = model.LeaveType;
                    existingLeave.StartDate = model.StartDate;
                    existingLeave.EndDate = model.EndDate;
                    existingLeave.Reason = model.Reason;
                    existingLeave.Status = model.Status;

                    _context.Update(existingLeave);
                    await _context.SaveChangesAsync();

                    TempData["Success"] = "Leave updated successfully";
                    return RedirectToAction(nameof(LeaveRequests));
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Please try again.");
                }
            }

            // If we got here, something failed, reload employee data
            var leave = await _context.Leaves
                .Include(l => l.Employee)
                .FirstOrDefaultAsync(l => l.LeaveId == model.LeaveId);

            return View(leave);
        }

        // POST: Delete Leave (Optional - if you want to add delete functionality)
        [HttpPost]
        public async Task<IActionResult> DeleteLeave(int id)
        {
            var leave = await _context.Leaves.FindAsync(id);
            if (leave == null)
            {
                return NotFound();
            }

            _context.Leaves.Remove(leave);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave deleted successfully";
            return RedirectToAction(nameof(LeaveRequests));
        }
    }
}