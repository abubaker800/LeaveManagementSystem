﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LeaveManagementSystem.Data;
using LeaveManagementSystem.Models;

namespace LeaveManagementSystem.Controllers
{
    [Authorize(Roles = "Employee")]
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public EmployeeController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // Helper method to get current employee
        private async Task<EmployeeModel> GetCurrentEmployee()
        {
            var user = await _userManager.GetUserAsync(User);
            return await _context.Employees.FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);
        }

        // Dashboard
        public async Task<IActionResult> Index()
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            var leaves = await _context.Leaves
                .Where(l => l.EmployeeId == employee.EmployeeId)
                .OrderByDescending(l => l.CreatedDate)
                .Take(5)
                .ToListAsync();

            ViewBag.Employee = employee;
            ViewBag.PendingLeaves = leaves.Count(l => l.Status == "Pending");
            ViewBag.ApprovedLeaves = leaves.Count(l => l.Status == "Approved");

            return View(leaves);
        }

        // View Profile
        public async Task<IActionResult> Profile()
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Edit Profile (Restricted)
        [HttpGet]
        public async Task<IActionResult> EditProfile()
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Edit Profile (Restricted)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProfile(EmployeeModel model)
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            // Only update allowed fields (Department and Designation)
            // Employee cannot update: EmployeeId, Name, CNIC, Email
            employee.Department = model.Department;
            employee.Designation = model.Designation;

            try
            {
                _context.Update(employee);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Profile updated successfully";
                return RedirectToAction(nameof(Profile));
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Unable to save changes. Please try again.");
            }

            return View(employee);
        }

        // GET: Apply for Leave
        [HttpGet]
        public IActionResult ApplyLeave()
        {
            return View();
        }

        // POST: Apply for Leave
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApplyLeave(LeaveModel model)
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Validate dates
                if (model.EndDate < model.StartDate)
                {
                    ModelState.AddModelError("EndDate", "End date must be after start date");
                    return View(model);
                }

                // Set employee and default values
                model.EmployeeId = employee.EmployeeId;
                model.Status = "Pending";
                model.CreatedDate = DateTime.Now;

                _context.Leaves.Add(model);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Leave request submitted successfully";
                return RedirectToAction(nameof(MyLeaves));
            }

            return View(model);
        }

        // View My Leaves
        public async Task<IActionResult> MyLeaves()
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            var leaves = await _context.Leaves
                .Where(l => l.EmployeeId == employee.EmployeeId)
                .OrderByDescending(l => l.CreatedDate)
                .ToListAsync();

            return View(leaves);
        }

        // GET: Edit Leave (Only Pending)
        [HttpGet]
        public async Task<IActionResult> EditLeave(int id)
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            var leave = await _context.Leaves
                .FirstOrDefaultAsync(l => l.LeaveId == id && l.EmployeeId == employee.EmployeeId);

            if (leave == null)
            {
                TempData["Error"] = "Leave request not found";
                return RedirectToAction(nameof(MyLeaves));
            }

            if (leave.Status != "Pending")
            {
                TempData["Error"] = "You can only edit pending leave requests";
                return RedirectToAction(nameof(MyLeaves));
            }

            return View(leave);
        }

        // POST: Edit Leave (Only Pending)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditLeave(LeaveModel model)
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            var leave = await _context.Leaves
                .FirstOrDefaultAsync(l => l.LeaveId == model.LeaveId && l.EmployeeId == employee.EmployeeId);

            if (leave == null)
            {
                TempData["Error"] = "Leave request not found";
                return RedirectToAction(nameof(MyLeaves));
            }

            if (leave.Status != "Pending")
            {
                TempData["Error"] = "You can only edit pending leave requests";
                return RedirectToAction(nameof(MyLeaves));
            }

            if (ModelState.IsValid)
            {
                // Validate dates
                if (model.EndDate < model.StartDate)
                {
                    ModelState.AddModelError("EndDate", "End date must be after start date");
                    return View(model);
                }

                // Update only allowed fields
                leave.LeaveType = model.LeaveType;
                leave.StartDate = model.StartDate;
                leave.EndDate = model.EndDate;
                leave.Reason = model.Reason;

                _context.Update(leave);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Leave updated successfully";
                return RedirectToAction(nameof(MyLeaves));
            }

            return View(model);
        }

        // POST: Cancel Leave (Only Pending)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelLeave(int id)
        {
            var employee = await GetCurrentEmployee();
            if (employee == null)
            {
                return NotFound();
            }

            var leave = await _context.Leaves
                .FirstOrDefaultAsync(l => l.LeaveId == id && l.EmployeeId == employee.EmployeeId);

            if (leave == null)
            {
                TempData["Error"] = "Leave request not found";
                return RedirectToAction(nameof(MyLeaves));
            }

            if (leave.Status != "Pending")
            {
                TempData["Error"] = "You can only cancel pending leave requests";
                return RedirectToAction(nameof(MyLeaves));
            }

            _context.Leaves.Remove(leave);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave cancelled successfully";
            return RedirectToAction(nameof(MyLeaves));
        }
    }
}